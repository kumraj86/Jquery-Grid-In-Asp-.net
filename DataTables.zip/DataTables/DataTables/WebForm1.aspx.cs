﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DataTables
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [System.Web.Services.WebMethod]
        public static string GetResults(string name)
        {
            DataTable dt = new DataTable();
            dt.TableName = "data";

            dt.Columns.Add("id");
            dt.Columns.Add("name");
            dt.Columns.Add("position");
            dt.Columns.Add("salary");
            dt.Columns.Add("start_date");
            dt.Columns.Add("office");
            dt.Columns.Add("extn");

            DataRow dr = dt.NewRow();
            dr[0] = "1";
            dr[1] = "Tiger Nixon";
            dr[2] = "System Architect";
            dr[3] = "$320,800";
            dr[4] = "2011/04/04";
            dr[5] = "Edinburgh";
            dr[6] = "5421";

            dt.Rows.Add(dr);


            dr = dt.NewRow();
            dr[0] = "2";
            dr[1] = "Tiger Nixon";
            dr[2] = "System Architect";
            dr[3] = "$320,800";
            dr[4] = "2011/04/04";
            dr[5] = "Edinburgh";
            dr[6] = "5421";

            dt.Rows.Add(dr);

            dt.AcceptChanges();

            DataSet ds = new DataSet();
            ds.Tables.Add(dt);
            string s = JsonConvert.SerializeObject(ds);
            return s;



        }
    }
}